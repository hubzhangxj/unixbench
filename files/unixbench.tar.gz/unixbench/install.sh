#!/usr/bin/env bash
build_unixbench() {
    set -e
    myOBJPATH=/tmp/unixbench
    if [ ! -d $myOBJPATH ]
    then
        mkdir -p $myOBJPATH
    fi
    sed -i 's/-march=native\ -mtune=native//' Makefile
    make
}

build_unixbench
